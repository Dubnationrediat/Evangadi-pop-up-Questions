import React from 'react'
import './Footer.css'
function Footer() {
  return (
    <div className="footer">
 
        Developed By:- Evangadi
   
</div>
  )
}

export default Footer