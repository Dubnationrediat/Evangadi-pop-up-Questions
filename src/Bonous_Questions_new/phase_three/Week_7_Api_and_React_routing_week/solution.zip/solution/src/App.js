import logo from './logo.svg';
import './App.css';
import React,{useState,useEffect} from 'react';
import Product from './Component/Product';


function App() {

  return (
    <>
  <Product></Product>
  </>
  );
}

export default App;
