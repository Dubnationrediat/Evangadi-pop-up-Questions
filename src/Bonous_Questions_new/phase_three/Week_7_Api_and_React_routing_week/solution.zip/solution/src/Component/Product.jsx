import React, { useContext, useEffect, useState } from "react";
import './Product.css'

function Product() {
 const [product, setProduct] = useState()

 useEffect(() => {
            fetch('https://fakestoreapi.com/products?limit=5')
            .then(res=>res.json())
            .then(response=>setProduct(response))
 
 }, [])
 
  return (
    <div>
        <h3 className="title">Your Product list</h3>
    <div className="forFlex">
        {
          product?.map((singleProduct)=>{
            let products = (
         <div
            className="card__container"
          >
              <img src={singleProduct.image} alt="" className="img_container" />
            <div>
              <h3>{singleProduct.title}</h3>
              <div>
                 <p>{`$${singleProduct.price}`}</p>
              </div>
            </div>
          </div>
            )
            return products
          })
        }

    </div>
    </div>
  );
}

export default Product;
