import React from 'react'
import ProfileCard from './components/ProfileCard'
import imageOne from './image/1689959227757.png'
import imageTwo from './image/download.png'
import imageThree from './image/images.jpeg'
function App() {
  return (
    <div className='app'>
     <ProfileCard image={imageOne} occupation="MERN developer" age="35" name="hile"/>
     <ProfileCard image={imageTwo} occupation="devOps" age="42" name="chaltu"/>
     <ProfileCard image={imageThree} occupation="QA/Tester" age="37" name="hagose"/>
    </div>
  )
}

export default App