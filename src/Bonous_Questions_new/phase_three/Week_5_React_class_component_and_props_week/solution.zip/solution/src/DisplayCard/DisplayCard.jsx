import React, { Component } from 'react'
import './DisplayCard.css'
export default class DisplayCard extends Component {
   
  render() {
    return (
      <div className={`${this.props.bg} frame`}>
              <h3> Full name : {this.props.fullName}</h3>
              <h3> State :{this.props.state}</h3>
              <h3>Country: {this.props.country}</h3>
              <h3>District : {this.props.district}</h3>
      </div>
    )
  }
}
