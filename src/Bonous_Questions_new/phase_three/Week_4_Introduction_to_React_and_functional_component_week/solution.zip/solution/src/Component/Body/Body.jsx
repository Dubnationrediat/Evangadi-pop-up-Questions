import React from 'react'
import banner from '../../Image/banner-puppies.jpg'
import imgOne from '../../Image/puppy-1.jpg'
import imgTwo from '../../Image/puppy-2.jpg'
import imgThree from '../../Image/puppy-3.jpg'
import imgFour from '../../Image/puppy-4.jpg'
import './Body.css'
function Body() {
  return (
   <>
<div className="banner">
        <img src={banner} alt="" />
    </div>
    <div className="allpuppys">
        <div className="whitepuppy">
         <img src={imgOne} alt="" />
        </div>
        <div className="missing">
            <p>Missing puppy here!</p>    
        </div>
        <div className="blackpuppy">
            <img src={imgTwo} alt="" />
        </div>
    </div>
    <div className="more">
        More puppies
    </div>
    <div className="twopuppys">
        <div className="pupyathand">
             <img src={imgThree} alt="" />
        </div>
        <div className="whitepuppy2">
            <img src={imgFour} alt=""/>
        </div>
    </div>
   </>
  )
}

export default Body