
import './App.css';
import Display from './Display/Display.jsx';

function App() {
  return (
    <>
  <Display/>
    </>
  );
}

export default App;
