import logo from './logo.svg';
import './App.css';
import Footer from './Component/Footer/Footer';
import Header from './Component/Header/Header';
import Body from './Component/Body/Body';
function App() {
  return (
    <div>
  <Header/>
  <Body/>
 <Footer/>
    </div>
  );
}

export default App;
