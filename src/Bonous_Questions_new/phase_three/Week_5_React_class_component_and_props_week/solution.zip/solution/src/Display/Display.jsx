import React, { Component } from 'react'
import DisplayCard from '../DisplayCard/DisplayCard.jsx'
export default class Display extends Component {
  render() {
    return (
      <>
<DisplayCard fullName="abebe tesema" state ='CA' country='USA' district='State Assembly' bg='bg1'/>
<DisplayCard fullName=" tesema tasew" state ='AA' country='Ethiopia' district='keranio' bg='bg2'/>
<DisplayCard fullName="kiros ayele" state ='Mk' country='Ethiopia' district='Axsum' bg='bg1'/>

      </>
    )
  }
}
