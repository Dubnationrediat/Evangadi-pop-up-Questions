
        function validateForm() {
            var firstName = document.getElementById("firstName").value;
            var lastName = document.getElementById("lastName").value;
            var email = document.getElementById("email").value;
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirmPassword").value;

            // Validate first name and last name
            if (!/^\D+$/.test(firstName) || !/^\D+$/.test(lastName)) {
                alert("First name and last name should only contain letters.");
                return false;
            }

            // Validate email
            if (!/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/.test(email)) {
                alert("Please enter a valid email address.");
                return false;
            }

            // Validate password
            if (!/(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{8,10}/.test(password)) {
                alert("Password must be between 8 and 10 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.");
                return false;
            }

            // Validate confirm password
            if (password !== confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }

            // Clear input fields
            document.getElementById("registrationForm").reset();

            // Show result message
            var fullName = firstName + " " + lastName;
            document.getElementById("resultMessage").innerHTML = "Thank you for registering Mr/Ms " + fullName;
            document.getElementById("registrationForm").style.display = "none";
            document.getElementById("resultMessage").style.display = "block";

            return false; // Prevent form submission
        }
  